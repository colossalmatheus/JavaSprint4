package br.com.fiap.banco.service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import br.com.fiap.banco.dao.AcessorioDao;

import br.com.fiap.banco.exception.BadInfoException;
import br.com.fiap.banco.exception.IdNotFoundException;
import br.com.fiap.banco.factory.ConnectionFactory;
import br.com.fiap.model.Acessorio;


public class AcessorioService {

private AcessorioDao acessorioDao;
	
	public AcessorioService() throws ClassNotFoundException, SQLException {
		Connection conn = ConnectionFactory.getConnection();
		acessorioDao = new AcessorioDao(conn);

	}
	
	
	public void cadastrar(Acessorio acessorio) throws ClassNotFoundException, SQLException, BadInfoException {
		acessorioDao.cadastrar(acessorio);
	}
	
	
	public List<Acessorio> listar() throws ClassNotFoundException, SQLException{
		return acessorioDao.listar();
	}
	
	public void remover(String nome) throws ClassNotFoundException, SQLException, IdNotFoundException {
		acessorioDao.remover(nome);
	}

	
	public void atualizar(Acessorio acessorio) throws ClassNotFoundException, SQLException, IdNotFoundException, BadInfoException {
		acessorioDao.atualizar(acessorio);
	}

	
	

	
}
