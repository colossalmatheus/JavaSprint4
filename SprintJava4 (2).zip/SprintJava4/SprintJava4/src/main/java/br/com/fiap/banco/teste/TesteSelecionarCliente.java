package br.com.fiap.banco.teste;

import java.util.List;


import br.com.fiap.banco.service.ClienteService;

import br.com.fiap.model.Cliente;

public class TesteSelecionarCliente {

	//Testar a pesquisa por nome
	public static void main(String[] args) {
		try {
			ClienteService service = new ClienteService();
			
			//Pesquisar os produtos por nome
			List<Cliente> lista = service.listar();
			
			//Exibir todos os nomes dos produtos retornados
			for (Cliente item : lista)
				System.out.println(item.getNome());
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}