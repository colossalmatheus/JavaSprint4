package br.com.fiap.model;

public class Acessorio {
	
	private String nome;
	private String tipo;
	private double preco;
	private String descricao;
	private String marca;
	private String modelo;
	
	
	public Acessorio() {};
	
	
	
	public Acessorio(String nome, String tipo, double preco, String descricao, String marca, String modelo) {
		super();
		this.nome = nome;
		this.tipo = tipo;
		this.preco = preco;
		this.descricao = descricao;
		this.marca = marca;
		this.modelo = modelo;
	}



	public String mostrarAtributo() {
		return "Nome: " + getNome()+
				"\nTipo: " + getTipo() +
				"\nPreco: " + getPreco()+
				"\nDescricao: " + getDescricao()+
				"\nMarca: " + getMarca()+
				"\nModelo: " + getModelo();
	}
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getTipo() {
		return tipo;
	}
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	public double getPreco() {
		return preco;
	}
	public void setPreco(double preco) {
		this.preco = preco;
	}
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	public String getMarca() {
		return marca;
	}
	public void setMarca(String marca) {
		this.marca = marca;
	}
	public String getModelo() {
		return modelo;
	}
	public void setModelo(String modelo) {
		this.modelo = modelo;
	}
}
