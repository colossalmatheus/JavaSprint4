package br.com.fiap.model;

public class Bike {

	private String modelo;
	private double preco;
	private String marca;
	private String numSerie;
	private boolean dano;
	
	public Bike() {};

	
	
	public Bike(String modelo, double preco, String marca, String numSerie, boolean dano) {
		this.modelo = modelo;
		this.preco = preco;
		this.marca = marca;
		this.numSerie = numSerie;
		this.dano = dano;
	}



	public String mostrarAtributo() {
		return "Modelo: " + getModelo()+
				"\nPreco: " + getPreco()+
				"\nMarca: " + getMarca() +
				"\nNumSerie: " + getNumSerie()+
				"\nDano: " + possuiDano();
				
	}
	
	

	public boolean possuiDano() {
	    return dano;
	}

	public void marcarDano() {
	    dano = true;
	}
	
	public double atualizarPreco(double precoAcessorio) {
		double soma = precoAcessorio + getPreco();
		return soma;
	}

	public String getModelo() {
		return modelo;
	}

	public void setModelo(String modelo) {
		this.modelo = modelo;
	}

	public double getPreco() {
		return preco;
	}

	public void setPreco(double preco) {
		this.preco = preco;
	}

	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	public String getNumSerie() {
		return numSerie;
	}

	public void setNumSerie(String numSerie) {
		this.numSerie = numSerie;
	}

	public boolean isDano() {
		return dano;
	}

	public void setDano(boolean dano) {
		this.dano = dano;
	}

}