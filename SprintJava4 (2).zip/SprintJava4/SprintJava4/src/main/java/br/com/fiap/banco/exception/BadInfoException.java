package br.com.fiap.banco.exception;

public class BadInfoException extends Exception {

	public BadInfoException(String message) {
		super(message);
	}
	
}
