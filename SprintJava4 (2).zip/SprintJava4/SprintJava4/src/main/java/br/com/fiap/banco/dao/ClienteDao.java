package br.com.fiap.banco.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import br.com.fiap.banco.exception.IdNotFoundException;
import br.com.fiap.model.Cliente;

public class ClienteDao {

	private Connection conn;

	public ClienteDao(Connection conn) {
		this.conn = conn;
	}

	public void cadastrar(Cliente cliente) throws ClassNotFoundException, SQLException {

		// Criar o objeto com o comando SQL configuravel
		PreparedStatement stm = conn.prepareStatement("INSERT INTO cliente (nome,cpf,nasc,nmUsuario,senhaUsuario,nfCliente) values (?,?,?,?,?,?)");

		// Setar os valores no comando SQL
		stm.setString(1, cliente.getNome());
		stm.setString(2, cliente.getCpf());
		stm.setString(3,cliente.getNasc());
		stm.setString(4,cliente.getNmUsuario());
		stm.setString(5, cliente.getSenhaUsuario());
		stm.setString(6, cliente.getNfCliente());

		// Executar o comando SQL
		stm.executeUpdate();
	}

	public List<Cliente> listar() throws ClassNotFoundException, SQLException {

		PreparedStatement stm = conn.prepareStatement("select * from cliente");

		ResultSet result = stm.executeQuery();
		List<Cliente> lista = new ArrayList<Cliente>();

		while (result.next()) {
			Cliente cliente = parse(result);
			lista.add(cliente);
		}

		return lista;
	}

	private Cliente parse(ResultSet result) throws SQLException {

		String nome = result.getString("nome");
		String cpf = result.getString("cpf");
		String nasc = result.getString("nasc");
		String nmUsuario = result.getString("nmusuario");
		String senhaUsuario = result.getString("senhaUsuario");
		String nfCliente = result.getString("nfCliente");

		Cliente cliente = new Cliente(nome,cpf,nasc,nmUsuario,senhaUsuario,nfCliente);

		return cliente;
	}
	
	
	public void remover(String nome) throws ClassNotFoundException, SQLException, IdNotFoundException {

		// PreparedStatement
		PreparedStatement stm = conn.prepareStatement("delete from cliente where nome = ?");
		// Setar os parametros na Query
		stm.setString(1, nome);
		// Executar a Query
		int linha = stm.executeUpdate();
		if (linha == 0)
			throw new IdNotFoundException("Nome n�o encontrado para remo��o");
	}

	public void atualizar(Cliente cliente) throws ClassNotFoundException, SQLException, IdNotFoundException {
		PreparedStatement stm = conn.prepareStatement("update cliente set senhaUsuario = ? where nmUsuario = ?");
		stm.setString(1, cliente.getSenhaUsuario());
		stm.setString(2, cliente.getNmUsuario());

		int linha = stm.executeUpdate();
		if (linha == 0)
			throw new IdNotFoundException("Nome n�o encontrado para atualizar");
	}

	

}