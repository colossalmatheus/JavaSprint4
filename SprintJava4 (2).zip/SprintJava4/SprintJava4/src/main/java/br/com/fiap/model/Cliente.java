package br.com.fiap.model;

public class Cliente extends Pessoa{
	private String nmUsuario;
	private String senhaUsuario;
	private String nfCliente;

	public Cliente() {};
	
	public Cliente(String nome, String cpf, String nasc, String nmUsuario, String  senhaUsuario, String nfCliente) {
		super(nome, cpf, nasc);
		this.nmUsuario = nmUsuario;
		this.senhaUsuario = senhaUsuario;
		this.nfCliente = nfCliente;
	}
	public String mostrarAtributo() {
		return "Nome: " + getNome()+
				"\nCpf: " + getCpf()+
				"\nNasc: " + getNasc() +
				"\nNome Usuario: " + getNmUsuario()+
				"\nSenha Usuario: " + getSenhaUsuario()+
				"\nNf Cliente: " + getNfCliente();
	
	}
	public String getNmUsuario() {
		return nmUsuario;
	}
	public void setNmUsuario(String nmUsuario) {
		this.nmUsuario = nmUsuario;
	}
	public String getSenhaUsuario() {
		return senhaUsuario;
	}
	public void setSenhaUsuario(String senhaUsuario) {
		this.senhaUsuario = senhaUsuario;
	}
	public String getNfCliente() {
		return nfCliente;
	}
	public void setNfCliente(String nfCliente) {
		this.nfCliente = nfCliente;
	}
}
