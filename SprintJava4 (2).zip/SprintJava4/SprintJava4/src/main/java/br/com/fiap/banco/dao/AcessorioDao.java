package br.com.fiap.banco.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.fiap.banco.exception.IdNotFoundException;
import br.com.fiap.model.Acessorio;


public class AcessorioDao {

	private Connection conn;

	public AcessorioDao(Connection conn) {
		this.conn = conn;
	}

	public void cadastrar(Acessorio acessorio) throws ClassNotFoundException, SQLException {

		
		PreparedStatement stm = conn.prepareStatement("INSERT INTO acessorio (nome,tipo,preco,descricao,marca,modelo) values (?,?,?,?,?,?)");

		
		stm.setString(1, acessorio.getNome());
		stm.setString(2, acessorio.getTipo());
		stm.setDouble(3,acessorio.getPreco());
		stm.setString(4,acessorio.getDescricao());
		stm.setString(5, acessorio.getMarca());
		stm.setString(6, acessorio.getModelo());

		
		stm.executeUpdate();
	}

	public List<Acessorio> listar() throws ClassNotFoundException, SQLException {

		PreparedStatement stm = conn.prepareStatement("select * from acessorio");

		ResultSet result = stm.executeQuery();
		List<Acessorio> lista = new ArrayList<Acessorio>();

		while (result.next()) {
			Acessorio acessorio = parse(result);
			lista.add(acessorio);
		}

		return lista;
	}

	private Acessorio parse(ResultSet result) throws SQLException {

		String nome = result.getString("nome");
		String tipo = result.getString("tipo");
		double preco = result.getDouble("preco");
		String descricao = result.getString("descricao");
		String marca = result.getString("marca");
		String modelo = result.getString("modelo");
	

		Acessorio acessorio = new Acessorio(nome,tipo,preco,descricao,marca,modelo);

		return acessorio;
	}
	
	
	public void remover(String nome) throws ClassNotFoundException, SQLException, IdNotFoundException {

		// PreparedStatement
		PreparedStatement stm = conn.prepareStatement("delete from acessorio where nome = ?");
		// Setar os parametros na Query
		stm.setString(1, nome);
		// Executar a Query
		int linha = stm.executeUpdate();
		if (linha == 0)
			throw new IdNotFoundException("Acessorio n�o encontrado para remo��o");
	}

	public void atualizar(Acessorio acessorio) throws ClassNotFoundException, SQLException, IdNotFoundException {
		PreparedStatement stm = conn.prepareStatement("update acessorio set modelo = ? where nome = ?");
		stm.setString(1, acessorio.getModelo());
		stm.setString(2, acessorio.getNome());

		int linha = stm.executeUpdate();
		if (linha == 0)
			throw new IdNotFoundException("Nome n�o encontrado para atualizar");
	}
	
	

	

}
