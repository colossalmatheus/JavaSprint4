package br.com.fiap.model;

public class Pessoa {
	
	private String nome;
	private String cpf;
	private String Nasc;
	
	public Pessoa() {};
	
	
	public Pessoa(String nome, String cpf, String nasc) {
		super();
		this.nome = nome;
		this.cpf = cpf;
		Nasc = nasc;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	

	public String getCpf() {
		return cpf;
	}
	
	
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public String getNasc() {
		return Nasc;
	}


	public void setNasc(String nasc) {
		Nasc = nasc;
	}
	
}
