package br.com.fiap.banco.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.fiap.banco.exception.IdNotFoundException;
import br.com.fiap.model.Bike;

public class BikeDao {
	
	private Connection conn;

	public BikeDao(Connection conn) {
		this.conn = conn;
	}

	public void cadastrar(Bike bike) throws ClassNotFoundException, SQLException {

		
		PreparedStatement stm = conn.prepareStatement("INSERT INTO bike (modelo,preco,marca,numSerie,dano) values (?,?,?,?,?)");

		
		stm.setString(1, bike.getModelo());
		stm.setDouble(2, bike.getPreco());
		stm.setString(3,bike.getMarca());
		stm.setString(4,bike.getNumSerie());
		stm.setBoolean(5, bike.isDano());

		
		stm.executeUpdate();
	}

	public List<Bike> listar() throws ClassNotFoundException, SQLException {

		PreparedStatement stm = conn.prepareStatement("select * from bike");

		ResultSet result = stm.executeQuery();
		List<Bike> lista = new ArrayList<Bike>();

		while (result.next()) {
			Bike bike = parse(result);
			lista.add(bike);
		}

		return lista;
	}

	private Bike parse(ResultSet result) throws SQLException {

		String modelo = result.getString("modelo");
		double preco = result.getDouble("preco");
		String marca = result.getString("marca");
		String numSerie = result.getString("numSerie");
		boolean dano = result.getBoolean("dano");
	

		Bike bike = new Bike(modelo,preco,marca,numSerie,dano);

		return bike;
	}
	
	
	public void remover(String modelo) throws ClassNotFoundException, SQLException, IdNotFoundException {

		// PreparedStatement
		PreparedStatement stm = conn.prepareStatement("delete from bike where modelo = ?");
		// Setar os parametros na Query
		stm.setString(1, modelo);
		// Executar a Query
		int linha = stm.executeUpdate();
		if (linha == 0)
			throw new IdNotFoundException("Bike n�o encontrado para remo��o");
	}

	public void atualizar(Bike bike) throws ClassNotFoundException, SQLException, IdNotFoundException {
		PreparedStatement stm = conn.prepareStatement("update bike set modelo = ? where numSerie = ?");
		stm.setString(1, bike.getModelo());
		stm.setString(2, bike.getNumSerie());

		int linha = stm.executeUpdate();
		if (linha == 0)
			throw new IdNotFoundException("Modelo n�o encontrado para atualizar");
	}

	

}
